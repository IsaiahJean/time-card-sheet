# time-card-sheet

<<<<<<< HEAD
<<<<<<< HEAD
#Time-card-sheet
=======
=======
>>>>>>> dmitriy

# pip install django
# pip install djangorestframework
# pip install django-corse-headers
<<<<<<< HEAD
>>>>>>> dmitriy
=======
>>>>>>> dmitriy
