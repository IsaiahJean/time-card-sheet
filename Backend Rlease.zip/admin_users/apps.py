from django.apps import AppConfig


class AdminUsersConfig(AppConfig):
    name = 'admin_users'
