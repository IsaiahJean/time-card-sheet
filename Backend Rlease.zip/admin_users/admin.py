from django.contrib import admin
from . models import UserDescription

# Register your models here.


admin.site.register(UserDescription)
