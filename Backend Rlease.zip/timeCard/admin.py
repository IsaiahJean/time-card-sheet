from django.contrib import admin
from . models import TimeCard

# Register your models here.


admin.site.register(TimeCard)
