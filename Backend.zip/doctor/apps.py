from django.apps import AppConfig


class DoctorConfig(AppConfig):
    name = 'doctor'
