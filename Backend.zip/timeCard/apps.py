from django.apps import AppConfig


class TimecardConfig(AppConfig):
    name = 'timeCard'
